@echo -off
echo "Booting Mainline Linux 7.3.5 ARM64 (ACPI + EFI Runtime)..."
\NP05J\LINUX\VMLINUZ.EFI initrd=\NP05J\LINUX\INITRD.XZ acpi=force efi=debug earlycon=efifb fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
