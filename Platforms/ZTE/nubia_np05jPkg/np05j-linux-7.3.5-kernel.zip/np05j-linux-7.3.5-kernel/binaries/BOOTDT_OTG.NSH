@echo -off
echo "=============================================================="
echo " Booting Mainline Linux 7.3.5 SM8750 DT (USB-C Host/OTG Mode)"
echo " Full Type-C Dual-Role + USB 3.0 SS + pmic-glink + All Phase 3"
echo "=============================================================="
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05JOTG.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
