@echo -off
echo "=============================================================="
echo " Booting Mainline Linux 7.3.5 SM8750 DT (Adreno 830v2 GPU Test)"
echo " Headless DRM/MSM GPU (0x44050001) + All Phase 3 + OLED efifb"
echo "=============================================================="
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05JGPU.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused msm.separate_gpu_kms=1 fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
