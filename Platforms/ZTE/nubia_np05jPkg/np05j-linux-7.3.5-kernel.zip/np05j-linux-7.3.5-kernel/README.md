# nubia NP05J (REDMAGIC Astra) — Mainline Linux 7.3.5 Kernel Bundle (Phase 3A.1)

Complete, reproducible Mainline Linux `7.3.5` ARM64 kernel, device tree, driver patches, config, initramfs, and ready-to-flash `logfs` image bundle for **nubia NP05J (REDMAGIC Astra)** — Qualcomm Snapdragon 8 Elite (**SM8750P / Pakala**, 24 GiB LPDDR5X, 1 TB UFS 4.0, 2400×1504 OLED).

## Contents

- `binaries/` — Ready-to-boot Phase 3A.1 artifacts (QEMU AAVMF 4/4 verified):
  - `logfs-linux7-dt.img` — Exact 8 MiB (4K-sector FAT12) UEFI `logfs` image
  - `VMLINUZ.EFI` — Linux 7.3.5 ARM64 EFI ZBOOT (ZSTD-22) kernel
  - `INITRD.XZ` — BusyBox + `np05j-tool` + `np05j-fw-load` + `np05j-status` initramfs
  - `NP05J.DTB` — Default SM8750 DT (Touchscreen + Wi-Fi 7 + BT + ADSP/CDSP + Battery + Fan + USB-C `ttyGS0`)
  - `NP05JGPU.DTB` — Isolated Adreno 830v2 GPU test DT (headless `DRM_MSM` with `msm.separate_gpu_kms=1`, preserves OLED `efifb`)
  - `NP05JOTG.DTB` — USB-C Dual-Role Host/OTG + USB 3.0 SS DT
  - `BOOTDT.NSH`, `BOOTDT_GPU.NSH`, `BOOTDT_OTG.NSH`, `BOOTDT_SAFE.NSH`, `BOOTACPI.NSH`, `startup.nsh`
- `dts/` — Device Tree sources (`sm8750-nubia-np05j-common.dtsi`, `sm8750-nubia-np05j.dts`, `sm8750-nubia-np05j-otg.dts`, `sm8750-nubia-np05j-gpu.dts`)
- `patches/` — Clean unified patches against upstream `linux-7.3.5`:
  - `0001-bluetooth-hci_qca-brahma-2.0-peri-baudrate.patch` — WCN7861 / BRAHMA 2.0 (`0x4021xxxx`) Peri SetBaudRateReq (`hci0 UP` hardware-verified)
  - `0002-input-touchscreen-synaptics-tcm2-spi.patch` — Synaptics S3930TB0A0 TCM v2 multi-touch SPI driver (full-duplex GPI DMA, `CMD_GET_TOUCH_REPORT_CONFIG = 0x25`)
  - `0003-wifi-ath12k-wcn7861-peach-0x110e.patch` — FastConnect 7900 / WCN7861 ("Peach" `17cb:110e`) QCC2072/Peach HAL + `bdwlan.e%02x` auto-load
  - `0004-pci-pwrctrl-wcn7861-110e.patch` — `pci17cb,110e` WCN PMU power sequencing match
  - `0005-drm-msm-adreno-830v2-0x44050001.patch` — Adreno 830v2 (`0x44050001`, `ADRENO_8XX_GEN1`, `gen80000_*`) catalog entry
  - `0006-arm64-dts-qcom-sm8750-nubia-np05j.patch` — NP05J DTS/DTSI + `qcom/Makefile`
  - `0007-pci-qcom-fix-bdf-to-sid-iommu-cells.patch` — Fix `qcom_pcie_config_sid_1_9_0()` to parse dynamic `#iommu-cells` (`#iommu-cells = <2>` / 5-cell `iommu-map` entries on SM8750)
  - `np05j-linux-7.3.5-all.patch` — All patches combined (`0001..0007`, verified clean with `patch --dry-run -p1`)
- `src/` — Direct copies of all added/modified Linux 7.3.5 driver files
- `configs/` — Full `np05j-linux-7.3.5-arm64.config`, all incremental `.frag` fragments + `prune_qcom_config.py`, plus legacy `np05j-linux-6.12.118-arm64.config`
- `initramfs/` — `np05j-tool.c` (`bt-up`, `touch-watch`, `wifi-scan`, `mount-vendor`, `gpu-info`, `spi-probe`) and complete `rootfs/` tree
- `scripts/` — `rebuild_kernel.sh` (one-command full rebuild from upstream `linux-7.3.5.tar.xz`), `pack_logfs.sh`, `test_qemu.sh`

## Quick Rebuild

```bash
./scripts/rebuild_kernel.sh /tmp/np05j-linux7
/tmp/np05j-linux7/pack_logfs.sh
/tmp/np05j-linux7/test_qemu.sh
```
