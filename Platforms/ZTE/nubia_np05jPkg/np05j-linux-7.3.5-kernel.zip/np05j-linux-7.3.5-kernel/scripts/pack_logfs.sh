#!/bin/bash
set -euo pipefail

IMG=/workspaces/Mu-Silicium/Device_np05j/logfs-linux7-dt.img
VMLINUZ=/tmp/np05j-linux7/build/arch/arm64/boot/vmlinuz.efi
DTB=/tmp/np05j-linux7/build/arch/arm64/boot/dts/qcom/sm8750-nubia-np05j.dtb
DTB_OTG=/tmp/np05j-linux7/build/arch/arm64/boot/dts/qcom/sm8750-nubia-np05j-otg.dtb
DTB_GPU=/tmp/np05j-linux7/build/arch/arm64/boot/dts/qcom/sm8750-nubia-np05j-gpu.dtb
INITRD=/tmp/np05j-linux7/initrd.xz
BDS_ZIP=/workspaces/Mu-Silicium/Device_np05j/np05j-bds-usb.zip
WORK=/tmp/np05j-linux7/stage

rm -rf "$WORK"
mkdir -p "$WORK/EFI/BOOT" "$WORK/NP05J/LINUX"

unzip -q -o "$BDS_ZIP" EFI/BOOT/BOOTAA64.EFI NP05J/Np05jProbe.efi -d "$WORK"
cp "$VMLINUZ" "$WORK/NP05J/LINUX/VMLINUZ.EFI"
cp "$DTB" "$WORK/NP05J/LINUX/NP05J.DTB"
cp "$DTB_OTG" "$WORK/NP05J/LINUX/NP05JOTG.DTB"
cp "$DTB_GPU" "$WORK/NP05J/LINUX/NP05JGPU.DTB"
cp "$INITRD" "$WORK/NP05J/LINUX/INITRD.XZ"

# Archive compiled DTBs in Device_np05j
cp "$DTB" /workspaces/Mu-Silicium/Device_np05j/sm8750-nubia-np05j.dtb
cp "$DTB_OTG" /workspaces/Mu-Silicium/Device_np05j/sm8750-nubia-np05j-otg.dtb
cp "$DTB_GPU" /workspaces/Mu-Silicium/Device_np05j/sm8750-nubia-np05j-gpu.dtb

# Phase 3 Default: Touchscreen S3930TB0A0 + Wi-Fi 7 WCN7861 + BT + ADSP/CDSP + Battery + Fan + ttyGS0
cat > "$WORK/NP05J/LINUX/BOOTDT.NSH" <<'EOF'
@echo -off
echo "=============================================================="
echo " Booting Mainline Linux 7.3.5 SM8750 DT (Phase 3)"
echo " Touch S3930 + Wi-Fi 7 WCN7861 + BT + ADSP/CDSP + Fan + ttyGS0"
echo "=============================================================="
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05J.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
EOF

# Phase 3 GPU Test Profile (isolated headless Adreno 830v2 /dev/dri/renderD128, preserves OLED efifb!)
cat > "$WORK/NP05J/LINUX/BOOTDT_GPU.NSH" <<'EOF'
@echo -off
echo "=============================================================="
echo " Booting Mainline Linux 7.3.5 SM8750 DT (Adreno 830v2 GPU Test)"
echo " Headless DRM/MSM GPU (0x44050001) + All Phase 3 + OLED efifb"
echo "=============================================================="
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05JGPU.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused msm.separate_gpu_kms=1 fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
EOF

# Phase 3 OTG: Full USB-C Type-C Dual-Role (Host/OTG + USB 3.0 SS + pmic-glink)
cat > "$WORK/NP05J/LINUX/BOOTDT_OTG.NSH" <<'EOF'
@echo -off
echo "=============================================================="
echo " Booting Mainline Linux 7.3.5 SM8750 DT (USB-C Host/OTG Mode)"
echo " Full Type-C Dual-Role + USB 3.0 SS + pmic-glink + All Phase 3"
echo "=============================================================="
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05JOTG.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
EOF

# Safety fallback: isolate PCIe0 / Remoteproc if needed (keeps UFS + Touch + USB-C ttyGS0!)
cat > "$WORK/NP05J/LINUX/BOOTDT_SAFE.NSH" <<'EOF'
@echo -off
echo "Booting Linux 7.3.5 SM8750 DT (Safe fallback: no PCIe0/Remoteproc)..."
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05J.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused initcall_blacklist=qcom_pcie_driver_init,qcom_pas_driver_init fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
EOF

# ACPI mode with Linux 7.3.5 (also used for QEMU AAVMF verification)
cat > "$WORK/NP05J/LINUX/BOOTACPI.NSH" <<'EOF'
@echo -off
echo "Booting Mainline Linux 7.3.5 ARM64 (ACPI + EFI Runtime)..."
\NP05J\LINUX\VMLINUZ.EFI initrd=\NP05J\LINUX\INITRD.XZ acpi=force efi=debug earlycon=efifb fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
EOF

# Startup script (both root and EFI/BOOT)
cat > "$WORK/startup.nsh" <<'EOF'
@echo -off
for %d in fs0 fs1 fs2 fs3 fs4 fs5 fs6 fs7 fs8 fs9
  if exist %d:\NP05J\LINUX\VMLINUZ.EFI then
    %d:
    cd \NP05J\LINUX
    echo "=============================================================="
    echo " nubia NP05J (REDMAGIC Astra) - Mainline Linux 7.3.5 Phase 3"
    echo "=============================================================="
    echo "  BOOTDT.NSH      : SM8750 DT (Touch+WiFi7+BT+NPU+Batt+ttyGS0)"
    echo "  BOOTDT_GPU.NSH  : SM8750 DT + Adreno 830v2 GPU (headless DRM)"
    echo "  BOOTDT_OTG.NSH  : SM8750 DT + USB-C Dual-Role Host/OTG + USB3"
    echo "  BOOTDT_SAFE.NSH : SM8750 DT without PCIe0/Remoteproc (fallback)"
    echo "  BOOTACPI.NSH    : Linux 7.3.5 ACPI mode (EFI Runtime ON)"
    echo "=============================================================="
    goto done
  endif
endfor
:done
EOF
cp "$WORK/startup.nsh" "$WORK/EFI/BOOT/startup.nsh"

for f in "$WORK/startup.nsh" "$WORK/EFI/BOOT/startup.nsh" "$WORK/NP05J/LINUX/"*.NSH; do
  sed -i 's/\r$//; s/$/\r/' "$f"
done

echo "=== Total staged payload size ==="
du -sh "$WORK"
du -sh "$WORK/EFI/BOOT/BOOTAA64.EFI" "$WORK/NP05J/Np05jProbe.efi" "$WORK/NP05J/LINUX/"*

# Build exact 8 MiB (8,388,608 bytes) 4096-byte-sector FAT12 image for NP05J logfs
rm -f "$IMG"
truncate -s 8388608 "$IMG"
mkfs.vfat -F 12 -S 4096 -s 1 -n NP05J_LNX7 "$IMG"

mmd -i "$IMG" ::/EFI ::/EFI/BOOT ::/NP05J ::/NP05J/LINUX
mcopy -i "$IMG" "$WORK/startup.nsh" ::/startup.nsh
mcopy -i "$IMG" "$WORK/EFI/BOOT/BOOTAA64.EFI" ::/EFI/BOOT/BOOTAA64.EFI
mcopy -i "$IMG" "$WORK/EFI/BOOT/startup.nsh" ::/EFI/BOOT/startup.nsh
mcopy -i "$IMG" "$WORK/NP05J/Np05jProbe.efi" ::/NP05J/Np05jProbe.efi
mcopy -i "$IMG" "$WORK/NP05J/LINUX/VMLINUZ.EFI" ::/NP05J/LINUX/VMLINUZ.EFI
mcopy -i "$IMG" "$WORK/NP05J/LINUX/NP05J.DTB" ::/NP05J/LINUX/NP05J.DTB
mcopy -i "$IMG" "$WORK/NP05J/LINUX/NP05JOTG.DTB" ::/NP05J/LINUX/NP05JOTG.DTB
mcopy -i "$IMG" "$WORK/NP05J/LINUX/NP05JGPU.DTB" ::/NP05J/LINUX/NP05JGPU.DTB
mcopy -i "$IMG" "$WORK/NP05J/LINUX/INITRD.XZ" ::/NP05J/LINUX/INITRD.XZ
mcopy -i "$IMG" "$WORK/NP05J/LINUX/BOOTDT.NSH" ::/NP05J/LINUX/BOOTDT.NSH
mcopy -i "$IMG" "$WORK/NP05J/LINUX/BOOTDT_GPU.NSH" ::/NP05J/LINUX/BOOTDT_GPU.NSH
mcopy -i "$IMG" "$WORK/NP05J/LINUX/BOOTDT_OTG.NSH" ::/NP05J/LINUX/BOOTDT_OTG.NSH
mcopy -i "$IMG" "$WORK/NP05J/LINUX/BOOTDT_SAFE.NSH" ::/NP05J/LINUX/BOOTDT_SAFE.NSH
mcopy -i "$IMG" "$WORK/NP05J/LINUX/BOOTACPI.NSH" ::/NP05J/LINUX/BOOTACPI.NSH

fsck.vfat -n "$IMG"
mdir -i "$IMG" ::/ ::/EFI/BOOT ::/NP05J ::/NP05J/LINUX
sha256sum "$IMG"
ls -lh "$IMG"
