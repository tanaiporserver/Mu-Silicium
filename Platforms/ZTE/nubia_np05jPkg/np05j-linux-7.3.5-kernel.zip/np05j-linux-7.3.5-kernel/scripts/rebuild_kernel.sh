#!/bin/bash
# One-command full rebuild of Mainline Linux 7.3.5 for nubia NP05J (REDMAGIC Astra, SM8750P)
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WORK_DIR="${1:-/tmp/np05j-linux7}"
SRC="$WORK_DIR/linux-7.3.5"
OUT="$WORK_DIR/build"

mkdir -p "$WORK_DIR"

if [ ! -d "$SRC" ]; then
  if [ ! -f "$WORK_DIR/linux-7.3.5.tar.xz" ]; then
    echo "Downloading upstream linux-7.3.5.tar.xz..."
    curl -fSL https://cdn.kernel.org/pub/linux/kernel/v7.x/linux-7.3.5.tar.xz \
      -o "$WORK_DIR/linux-7.3.5.tar.xz"
  fi
  echo "Extracting linux-7.3.5..."
  tar -xf "$WORK_DIR/linux-7.3.5.tar.xz" -C "$WORK_DIR"
  echo "Applying NP05J unified kernel patch..."
  patch -p1 -d "$SRC" < "$BUNDLE_DIR/patches/np05j-linux-7.3.5-all.patch"
fi

mkdir -p "$OUT"
cp "$BUNDLE_DIR/configs/np05j-linux-7.3.5-arm64.config" "$OUT/.config"
make -C "$SRC" O="$OUT" ARCH=arm64 LLVM=1 olddefconfig

echo "Building vmlinuz.efi and all 3 NP05J DTBs..."
make -C "$SRC" O="$OUT" ARCH=arm64 LLVM=1 -j"$(nproc)" \
  vmlinuz.efi \
  qcom/sm8750-nubia-np05j.dtb \
  qcom/sm8750-nubia-np05j-otg.dtb \
  qcom/sm8750-nubia-np05j-gpu.dtb

echo "Rebuilding np05j-tool & initrd.xz..."
rm -rf "$WORK_DIR/initramfs"
cp -a "$BUNDLE_DIR/initramfs/rootfs" "$WORK_DIR/initramfs"
cp "$BUNDLE_DIR/initramfs/np05j-tool.c" "$WORK_DIR/np05j-tool.c"
if command -v aarch64-linux-gnu-gcc >/dev/null 2>&1; then
  aarch64-linux-gnu-gcc -Os -static -Wall -Wextra \
    -o "$WORK_DIR/initramfs/bin/np05j-tool" "$WORK_DIR/np05j-tool.c"
  aarch64-linux-gnu-strip "$WORK_DIR/initramfs/bin/np05j-tool"
fi
(cd "$WORK_DIR/initramfs" && find . | cpio -o -H newc --owner=0:0 2>/dev/null | xz -9 --check=crc32 > "$WORK_DIR/initrd.xz")

cp "$BUNDLE_DIR/scripts/pack_logfs.sh" "$WORK_DIR/pack_logfs.sh"
cp "$BUNDLE_DIR/scripts/test_qemu.sh" "$WORK_DIR/test_qemu.sh"
chmod +x "$WORK_DIR/pack_logfs.sh" "$WORK_DIR/test_qemu.sh"

echo "Build complete!"
ls -lh "$OUT/arch/arm64/boot/vmlinuz.efi" \
       "$OUT/arch/arm64/boot/dts/qcom/sm8750-nubia-np05j"*.dtb \
       "$WORK_DIR/initrd.xz"
echo "Run '$WORK_DIR/pack_logfs.sh' to generate 8 MiB logfs-linux7-dt.img."
